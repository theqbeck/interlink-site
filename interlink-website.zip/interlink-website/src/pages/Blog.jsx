import React from 'react'
export default function Blog(){
  return (
    <section className="section">
      <div className="container">
        <h2>Blog</h2>
        <p className="muted">Coming soon — guides on visas, schools, and moving to Spain.</p>
      </div>
    </section>
  )
}
